package model.map;

public class Building {
}
