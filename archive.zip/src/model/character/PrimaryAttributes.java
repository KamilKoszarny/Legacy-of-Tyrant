package model.character;

public class PrimaryAttributes {
    public Double strength;
    public Double durability;
    public Double stamina;
    public Double eye;
    public Double arm;
    public Double agility;
    public Double knowledge;
    public Double focus;
    public Double charisma;

}
