package model.armor;

public interface Armor {
}
